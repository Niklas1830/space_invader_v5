var searchData=
[
  ['player_5fship_0',['player_ship',['../classplayer__ship.html',1,'']]],
  ['power_5fups_1',['power_ups',['../classpower__ups.html',1,'']]]
];
