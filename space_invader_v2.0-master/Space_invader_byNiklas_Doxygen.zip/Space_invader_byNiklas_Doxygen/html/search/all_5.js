var searchData=
[
  ['is_5falive_0',['is_alive',['../classpower__ups.html#aeef6664b7998560ae4b0679c0ea31752',1,'power_ups']]],
  ['is_5fplayer_5fhit_1',['is_player_hit',['../classpower__ups.html#a91888365065c51652b60494bcc854f41',1,'power_ups']]],
  ['is_5fused_2',['is_used',['../classpower__ups.html#a6a55f87963dac8139865daa867bea11a',1,'power_ups']]],
  ['isalive_3',['isalive',['../classalien.html#a3dd0166afe7adbf30bd8739dcd9815ae',1,'alien']]],
  ['isonscreen_4',['isOnScreen',['../classbullet.html#af0521e3a905e4b90cb4bbeecf2eb2f66',1,'bullet']]],
  ['isstartofgame_5',['isStartOfGame',['../classplayer__ship.html#a868a6fe85631db9fb65d63f321c64ee9',1,'player_ship']]]
];
