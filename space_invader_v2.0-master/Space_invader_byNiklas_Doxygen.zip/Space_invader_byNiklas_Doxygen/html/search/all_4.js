var searchData=
[
  ['game_5fevents_0',['game_events',['../classgame__events.html',1,'game_events'],['../classgame__events.html#a8d58cadcf999214ff990a992e2ff9f68',1,'game_events::game_events()']]],
  ['getbulletspeed_1',['getBulletspeed',['../classbullet.html#ac213d2c95524f5a7fe19ee33ee5a3a90',1,'bullet']]],
  ['getposx_2',['getPosX',['../classplayer__ship.html#ade59a78f13a916db7c656d094e1a771b',1,'player_ship']]],
  ['getpoxy_3',['getPoxY',['../classplayer__ship.html#a554fc3c408972f508d0b6d447f7bdf71',1,'player_ship']]],
  ['getsprite_4',['getsprite',['../classalien.html#a34837218714ea97691a55c380eb768ed',1,'alien::getSprite()'],['../classpower__ups.html#a05a2c8f4f1b341f8497d86467e92fdef',1,'power_ups::getSprite()']]]
];
