var searchData=
[
  ['alien_0',['alien',['../classalien.html#a41bde1570f78c991c215ba334f9d247c',1,'alien']]],
  ['alien_5fgetx_1',['alien_getX',['../classalien.html#a7ef5689e7edfef0914c4203e4b55467d',1,'alien']]],
  ['alien_5fgety_2',['alien_getY',['../classalien.html#a1aa23f1dde86784a2e1c3d9ed10a54b2',1,'alien']]]
];
