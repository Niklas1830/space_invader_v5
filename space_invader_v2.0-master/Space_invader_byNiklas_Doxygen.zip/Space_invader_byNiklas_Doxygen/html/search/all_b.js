var searchData=
[
  ['screen_5fstate_0',['screen_state',['../classscreen__state.html',1,'screen_state'],['../classscreen__state.html#ad993c29a10b5648ae1b1032f298214ca',1,'screen_state::screen_state()']]],
  ['set_5falive_1',['set_alive',['../classpower__ups.html#ab2ecc85a75c276172d6ac7bd7865a1a0',1,'power_ups']]],
  ['set_5fplayer_5fhit_2',['set_player_hit',['../classpower__ups.html#a30e524b6f1f344815cfec442b66de13d',1,'power_ups']]],
  ['set_5fshoot_5fspeed_3',['set_Shoot_Speed',['../classplayer__ship.html#a45cf00b1ffa811dda85ad4e8a9e4ee00',1,'player_ship']]],
  ['set_5fuse_5fstate_4',['set_use_state',['../classpower__ups.html#abe8c662ff95ff1a28019a97b23c7a056',1,'power_ups']]],
  ['setbulletspeed_5',['setBulletSpeed',['../classbullet.html#a91d6ea2b029ab3e83c83e074af1bc6fa',1,'bullet']]],
  ['setstartofgame_6',['setStartOfGame',['../classplayer__ship.html#a93fdd374e71903e488c94b09bbafbe31',1,'player_ship']]]
];
