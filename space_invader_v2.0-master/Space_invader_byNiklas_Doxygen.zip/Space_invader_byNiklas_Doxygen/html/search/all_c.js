var searchData=
[
  ['update_0',['update',['../classalien.html#a81403c7c227b37ea7b74d38f6e775a88',1,'alien::update()'],['../classplayer__ship.html#a700c10b37213811ae787fa0feba5d70a',1,'player_ship::update()']]],
  ['updateposition_1',['updateposition',['../classgame__events.html#a71e365bb9dcbc9179df426033968459c',1,'game_events::updateposition()'],['../classbullet.html#ab516e60f25a2727f02b8b6caf1849a79',1,'bullet::updatePosition()']]]
];
